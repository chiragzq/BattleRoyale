import java.awt.*;
/**
 * A Dropped Item of Armor
 */
public class Armor extends RoundItem
{
    public Armor(int x, int y) {
        super(x, y, 30);
    }
}