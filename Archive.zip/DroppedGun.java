
/**
 *A Start of a dropped weapons
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DroppedGun extends RoundItem
{
    public DroppedGun(int x, int y)
    {
        super(x, y, 65);
    }
    
}