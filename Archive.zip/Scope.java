/**
 * The scope of a player
 */
public class Scope extends RoundItem {
    public Scope(int x, int y) {
        super(x, y, 30);
    }
}